# حساب کتاب — Android Project

یہ ایک Native Android/Kotlin پروجیکٹ ہے۔ اس میں Jetpack/تیسرے فریق کی UI dependency درکار نہیں۔

## GitHub سے APK بنانے کا طریقہ
1. ZIP کو Extract کریں۔
2. GitHub پر نیا repository بنائیں۔
3. Extract کیے گئے فولڈر کے اندر موجود تمام فائلیں اور فولڈرز repository کے root میں upload کریں (ZIP فائل کو اکیلا upload نہ کریں)۔
4. `main` branch پر push کریں۔
5. GitHub میں **Actions** کھولیں، `Build Android APK` workflow مکمل ہونے دیں۔
6. مکمل ہونے کے بعد workflow run کے نیچے **Artifacts** میں `hisab-kitab-debug-apk` ڈاؤن لوڈ کریں۔
7. ZIP extract کریں؛ اس میں `app-debug.apk` ہوگی۔

## اہم خصوصیات
- اردو / English زبان سوئچ
- Sign up / Login / Forgot password (ریکوری کوڈ کے ذریعے)
- کھاتہ دار اور اس کے متعدد اندراجات
- ہر انٹری میں صرف ایک سمت: وصولی یا ادائیگی
- خودکار وصولی، ادائیگی اور خالص بیلنس
- انٹری Edit/Delete پر پاس ورڈ کی تصدیق
- کھاتے کے مینو میں Edit، Share، Delete
- بیک اپ ڈیٹا Share کے ذریعے JSON متن کی صورت میں

## اہم نوٹ
- یہ ابتدائی ورژن ڈیٹا اسی فون پر محفوظ کرتا ہے۔ App uninstall یا فون تبدیل کرنے سے پہلے Backup/Share محفوظ کرلیں۔
- Forgot Password کے لیے سائن اپ کے وقت دکھایا گیا Recovery Code ضروری ہے۔ اسے محفوظ رکھیں۔
- Backup فی الحال شیئر شیٹ میں JSON متن کے طور پر برآمد ہوتا ہے؛ اس ورژن میں خودکار cloud sync یا JSON import/restore شامل نہیں۔
- حقیقی ای میل پر password reset کے لیے Firebase یا کسی backend کی configuration درکار ہوگی؛ اس ZIP میں offline recovery code استعمال کیا گیا ہے۔
- APK debug-signed ہوگی، ذاتی فون پر ٹیسٹنگ کے لیے۔ Play Store یا مستقل تقسیم کے لیے release signing الگ configure کرنا ہوگی۔

## Build configuration
- Android Gradle Plugin 8.6.1
- Gradle 8.7
- Kotlin 2.0.20
- JDK 17
- compileSdk 35 / targetSdk 35 / minSdk 23
- NDK درکار نہیں، اس لیے NDK version mismatch نہیں ہوگا۔
