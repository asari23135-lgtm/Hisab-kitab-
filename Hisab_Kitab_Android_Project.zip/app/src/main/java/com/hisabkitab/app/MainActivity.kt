package com.hisabkitab.app

import android.app.*
import android.os.Bundle
import android.content.*
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.*

data class Entry(var note:String, var receive:Long, var pay:Long, var date:String)
data class Ledger(var name:String, val entries:MutableList<Entry> = mutableListOf())

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("hisab_kitab_store", MODE_PRIVATE) }
    private val ledgers = mutableListOf<Ledger>()
    private var language = "ur"
    private var loggedIn = false
    private var screenLedger: Ledger? = null
    private lateinit var root: LinearLayout
    private val green = 0xFF176B50.toInt()
    private val gold = 0xFFD6A84F.toInt()
    private val ink = 0xFF20312B.toInt()

    private fun t(ur:String, en:String) = if (language=="ur") ur else en
    private fun hash(s:String) = MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        language = prefs.getString("language","ur") ?: "ur"
        loadData()
        loggedIn = prefs.getBoolean("logged_in", false) && prefs.contains("password_hash")
        if (loggedIn) dashboard() else authScreen()
    }

    private fun base(title:String? = null): LinearLayout {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20,18,20,18)
            setBackgroundColor(0xFFF5F7F4.toInt())
            layoutDirection = if (language=="ur") View.LAYOUT_DIRECTION_RTL else View.LAYOUT_DIRECTION_LTR
        }
        if (title != null) {
            val top = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL }
            val heading = TextView(this).apply { text=title; textSize=25f; setTextColor(green); typeface=Typeface.DEFAULT_BOLD }
            top.addView(heading, LinearLayout.LayoutParams(0,-2,1f))
            val lang = Button(this).apply { text=if(language=="ur") "EN" else "اردو"; setOnClickListener { language=if(language=="ur") "en" else "ur"; prefs.edit().putString("language",language).apply(); if(screenLedger!=null) accountScreen(screenLedger!!) else if(loggedIn) dashboard() else authScreen() } }
            top.addView(lang)
            root.addView(top)
        }
        return root
    }

    private fun text(s:String, size:Float=16f, color:Int=ink, bold:Boolean=false): TextView =
        TextView(this).apply { text=s; textSize=size; setTextColor(color); if(bold) typeface=Typeface.DEFAULT_BOLD; setPadding(4,8,4,8) }

    private fun btn(s:String, action:()->Unit, color:Int=green): Button =
        Button(this).apply { text=s; setTextColor(-1); setBackgroundTintList(android.content.res.ColorStateList.valueOf(color)); setOnClickListener { action() } }

    private fun field(hint:String, value:String=""): EditText = EditText(this).apply {
        this.hint=hint; setText(value); textSize=16f; setSingleLine(true)
        setPadding(14,8,14,8)
    }

    private fun show(view:View) { setContentView(view) }
    private fun authScreen() {
        screenLedger=null
        val box=base("حساب کتاب")
        box.gravity=Gravity.CENTER_HORIZONTAL
        box.addView(text("حساب کتاب",32f,green,true))
        box.addView(text(t("اپنے حساب کا آسان اور محفوظ ریکارڈ","Your simple and secure personal ledger"),15f))
        val user=field(t("یوزر نام","Username"))
        val pass=field(t("پاس ورڈ","Password")).apply { inputType= android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD }
        box.addView(user); box.addView(pass)
        box.addView(btn(t("لاگ اِن","Log in"), {
            val stored=prefs.getString("password_hash",null)
            if(stored==null) { toast(t("پہلے سائن اَپ کریں","Please sign up first")); return@btn }
            if(hash(pass.text.toString())==stored && user.text.toString()==prefs.getString("username","")) {
                loggedIn=true; prefs.edit().putBoolean("logged_in",true).apply(); dashboard()
            } else toast(t("یوزر نام یا پاس ورڈ درست نہیں","Incorrect username or password"))
        }))
        box.addView(btn(t("سائن اَپ","Sign up"), { signupDialog() }, gold))
        box.addView(btn(t("پاس ورڈ بھول گئے؟","Forgot password?"), { forgotDialog() }, 0xFF687A72.toInt()))
        show(box)
    }

    private fun signupDialog() {
        val u=field(t("یوزر نام","Username")); val p=field(t("کم از کم 6 حروف کا پاس ورڈ","Password (6+ characters)"))
        val layout=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(22,4,22,4); addView(u); addView(p) }
        AlertDialog.Builder(this).setTitle(t("نیا اکاؤنٹ بنائیں","Create account")).setView(layout)
            .setPositiveButton(t("بنائیں","Create")) { _,_ ->
                if(u.text.isBlank() || p.text.length<6) { toast(t("یوزر نام اور کم از کم 6 حروف کا پاس ورڈ درج کریں","Enter username and a password of at least 6 characters")); return@setPositiveButton }
                if(prefs.contains("password_hash")) { toast(t("اکاؤنٹ پہلے سے موجود ہے","An account already exists on this device")); return@setPositiveButton }
                val recovery=UUID.randomUUID().toString().replace("-","").take(12).uppercase(Locale.ROOT)
                prefs.edit().putString("username",u.text.toString()).putString("password_hash",hash(p.text.toString())).putString("recovery_code",recovery).putBoolean("logged_in",true).apply()
                loggedIn=true
                AlertDialog.Builder(this).setTitle(t("آپ کا بیک اَپ / ریکوری کوڈ","Your backup / recovery code"))
                    .setMessage("$recovery\n\n"+t("اس کوڈ کو محفوظ جگہ لکھ لیں۔ پاس ورڈ بھولنے پر یہ درکار ہوگا۔","Save this code somewhere safe. It is required to reset your password."))
                    .setPositiveButton("OK") { _,_-> dashboard() }.setCancelable(false).show()
            }.setNegativeButton(t("منسوخ","Cancel"),null).show()
    }

    private fun forgotDialog() {
        val code=field(t("ریکوری کوڈ","Recovery code")); val p=field(t("نیا پاس ورڈ","New password"))
        p.inputType= android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        val l=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(22,4,22,4); addView(code); addView(p) }
        AlertDialog.Builder(this).setTitle(t("پاس ورڈ تبدیل کریں","Reset password")).setView(l)
            .setPositiveButton(t("تبدیل کریں","Reset")) { _,_->
                if(code.text.toString().equals(prefs.getString("recovery_code",""),true) && p.text.length>=6) {
                    prefs.edit().putString("password_hash",hash(p.text.toString())).putBoolean("logged_in",false).apply()
                    toast(t("پاس ورڈ تبدیل ہوگیا، اب لاگ اِن کریں","Password reset. Please log in")); authScreen()
                } else toast(t("ریکوری کوڈ غلط ہے یا نیا پاس ورڈ چھوٹا ہے","Invalid recovery code or password too short"))
            }.setNegativeButton(t("منسوخ","Cancel"),null).show()
    }

    private fun dashboard() {
        screenLedger=null
        val box=base(t("حساب کتاب","Hisab Kitab"))
        box.addView(text(t("آپ کے کھاتے","Your ledgers"),19f,ink,true))
        if(ledgers.isEmpty()) {
            val space=Space(this); box.addView(space,LinearLayout.LayoutParams(1,0,1f))
            val plus=btn("+", { newLedgerDialog() }, green).apply { textSize=42f; minHeight=150 }
            box.addView(plus,LinearLayout.LayoutParams(-1,150))
            box.addView(text(t("نیا کھاتہ بنانے کے لیے پلس دبائیں","Tap plus to create your first ledger"),15f))
            val space2=Space(this); box.addView(space2,LinearLayout.LayoutParams(1,0,1f))
        } else {
            val scroll=ScrollView(this); val list=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
            ledgers.forEach { ledger ->
                val card=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL; setPadding(12,8,12,8); setBackgroundColor(-1) }
                val info=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
                val sums=totals(ledger)
                info.addView(text(ledger.name,19f,green,true))
                info.addView(text("${t("لینے ہیں","Receivable")}: ${sums.first}    ${t("دینے ہیں","Payable")}: ${sums.second}",13f))
                card.addView(info,LinearLayout.LayoutParams(0,-2,1f))
                card.addView(btn("⋮",{ ledgerMenu(ledger) },gold))
                card.setOnClickListener { accountScreen(ledger) }
                list.addView(card,LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=10 })
            }
            scroll.addView(list); box.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
            box.addView(btn("+  "+t("نیا کھاتہ","New ledger"),{newLedgerDialog()}))
        }
        box.addView(btn(t("بیک اَپ / شیئر ڈیٹا","Backup / Share data"),{ shareBackup() },gold))
        box.addView(btn(t("لاگ آؤٹ","Log out"),{ loggedIn=false; prefs.edit().putBoolean("logged_in",false).apply(); authScreen() },0xFF687A72.toInt()))
        show(box)
    }

    private fun newLedgerDialog() {
        val name=field(t("کھاتہ دار کا نام","Account holder name"))
        AlertDialog.Builder(this).setTitle(t("نیا کھاتہ","New ledger")).setView(name)
            .setPositiveButton(t("اگلا","Next")) { _,_->
                if(name.text.isBlank()) { toast(t("نام درج کریں","Enter a name")); return@setPositiveButton }
                val l=Ledger(name.text.toString()); ledgers.add(l); saveData(); accountScreen(l); entryDialog(l,null)
            }.setNegativeButton(t("منسوخ","Cancel"),null).show()
    }

    private fun accountScreen(l:Ledger) {
        screenLedger=l
        val box=base(l.name)
        val sums=totals(l)
        box.addView(text(t("کل لینے ہیں:","Total receivable:")+" ${sums.first}",19f,green,true))
        box.addView(text(t("کل دینے ہیں:","Total payable:")+" ${sums.second}",19f,0xFF9A5B20.toInt(),true))
        val net=sums.first-sums.second
        val status=if(net>0) t("خالص: آپ نے لینے ہیں","Net: To receive") else if(net<0) t("خالص: آپ نے دینے ہیں","Net: To pay") else t("حساب برابر ہے","Settled")
        box.addView(text("$status  ${kotlin.math.abs(net)}",17f,ink,true))
        box.addView(btn("+  "+t("نئی انٹری","New entry"),{entryDialog(l,null)}))
        val scroll=ScrollView(this); val list=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        l.entries.forEachIndexed { index,e ->
            val card=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(12,8,12,8); setBackgroundColor(-1) }
            card.addView(text(e.note.ifBlank { t("بغیر نوٹ","No note") },17f,ink,true))
            card.addView(text("${t("لینے ہیں","Receive")}: ${e.receive}    ${t("دینے ہیں","Pay")}: ${e.pay}",15f))
            card.addView(text(e.date,13f))
            val actions=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
            actions.addView(btn(t("ایڈٹ","Edit"),{ verifyPassword { entryDialog(l,index) } },gold),LinearLayout.LayoutParams(0,-2,1f))
            actions.addView(btn(t("ڈیلیٹ","Delete"),{ verifyPassword { confirmDeleteEntry(l,index) } },0xFF9A4545.toInt()),LinearLayout.LayoutParams(0,-2,1f))
            card.addView(actions); list.addView(card,LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=10 })
        }
        scroll.addView(list); box.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        box.addView(btn(t("واپس","Back"),{dashboard()},0xFF687A72.toInt()))
        show(box)
    }

    private fun entryDialog(l:Ledger,index:Int?) {
        val old=if(index!=null) l.entries[index] else null
        val note=field(t("نوٹ","Note"),old?.note ?: "")
        val receive=field(t("پیسے لینے ہیں (رقم)","Money to receive"),old?.receive?.takeIf{it>0}?.toString() ?: "")
        val pay=field(t("پیسے دینے ہیں (رقم)","Money to pay"),old?.pay?.takeIf{it>0}?.toString() ?: "")
        val date=field(t("تاریخ: YYYY-MM-DD","Date: YYYY-MM-DD"),old?.date ?: SimpleDateFormat("yyyy-MM-dd",Locale.US).format(Date()))
        val form=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(20,4,20,4); addView(note); addView(receive); addView(pay); addView(date) }
        AlertDialog.Builder(this).setTitle(t("کھاتے کی انٹری","Ledger entry")).setView(form)
            .setPositiveButton(t("محفوظ کریں","Save")) { _,_->
                val r=receive.text.toString().toLongOrNull() ?: 0L
                val p=pay.text.toString().toLongOrNull() ?: 0L
                if(r<0 || p<0 || (r>0 && p>0) || (r==0L && p==0L)) { toast(t("صرف ایک رقم درج کریں: لینے ہیں یا دینے ہیں","Enter exactly one positive amount: receivable OR payable")); return@setPositiveButton }
                val e=Entry(note.text.toString(),r,p,date.text.toString())
                if(index==null) l.entries.add(e) else { l.entries[index]=e }
                saveData(); accountScreen(l)
            }.setNegativeButton(t("منسوخ","Cancel"),null).show()
    }

    private fun verifyPassword(done:()->Unit) {
        val p=field(t("پاس ورڈ درج کریں","Enter password")).apply { inputType=android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD }
        AlertDialog.Builder(this).setTitle(t("تصدیق ضروری ہے","Password verification")).setView(p)
            .setPositiveButton(t("تصدیق","Verify")) { _,_-> if(hash(p.text.toString())==prefs.getString("password_hash","")) done() else toast(t("پاس ورڈ غلط ہے","Incorrect password")) }
            .setNegativeButton(t("منسوخ","Cancel"),null).show()
    }

    private fun confirmDeleteEntry(l:Ledger,i:Int) {
        AlertDialog.Builder(this).setMessage(t("کیا یہ انٹری حذف کرنی ہے؟","Delete this entry?"))
            .setPositiveButton(t("حذف کریں","Delete")) { _,_-> l.entries.removeAt(i); saveData(); accountScreen(l) }
            .setNegativeButton(t("منسوخ","Cancel"),null).show()
    }

    private fun ledgerMenu(l:Ledger) {
        val opts=arrayOf(t("ایڈٹ","Edit"),t("شیئر","Share"),t("ڈیلیٹ","Delete"))
        AlertDialog.Builder(this).setItems(opts) { _,which->
            when(which) {
                0 -> verifyPassword { val n=field(t("کھاتہ دار کا نام","Account holder name"),l.name)
                    AlertDialog.Builder(this).setTitle(t("نام تبدیل کریں","Edit name")).setView(n)
                        .setPositiveButton(t("محفوظ","Save")) { _,_-> if(n.text.isNotBlank()) { l.name=n.text.toString(); saveData(); dashboard() } }
                        .setNegativeButton(t("منسوخ","Cancel"),null).show()
                }
                1 -> shareLedger(l)
                2 -> verifyPassword { AlertDialog.Builder(this).setMessage(t("پورا کھاتہ حذف ہو جائے گا۔ جاری رکھیں؟","This ledger and all its entries will be deleted. Continue?"))
                    .setPositiveButton(t("حذف","Delete")) { _,_-> ledgers.remove(l); saveData(); dashboard() }.setNegativeButton(t("منسوخ","Cancel"),null).show() }
            }
        }.show()
    }

    private fun totals(l:Ledger):Pair<Long,Long> {
        var r=0L; var p=0L
        l.entries.forEach { r+=it.receive; p+=it.pay }
        return Pair(r,p)
    }

    private fun shareLedger(l:Ledger) {
        val sums=totals(l); val body=buildString {
            append("${l.name}\n")
            append("${t("کل لینے ہیں","Receivable")}: ${sums.first}\n${t("کل دینے ہیں","Payable")}: ${sums.second}\n\n")
            l.entries.forEach { append("${it.date} | ${it.note} | +${it.receive} | -${it.pay}\n") }
        }
        shareText(body)
    }

    private fun shareBackup() {
        val arr=JSONArray()
        ledgers.forEach { l->
            val obj=JSONObject().put("name",l.name); val es=JSONArray()
            l.entries.forEach { es.put(JSONObject().put("note",it.note).put("receive",it.receive).put("pay",it.pay).put("date",it.date)) }
            obj.put("entries",es); arr.put(obj)
        }
        shareText(JSONObject().put("app","Hisab Kitab").put("version",1).put("ledgers",arr).toString(2))
    }
    private fun shareText(s:String) {
        val i=Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT,s)
        startActivity(Intent.createChooser(i,t("شیئر کریں","Share")))
    }

    private fun saveData() {
        val a=JSONArray()
        ledgers.forEach { l->
            val o=JSONObject().put("name",l.name); val es=JSONArray()
            l.entries.forEach { es.put(JSONObject().put("note",it.note).put("receive",it.receive).put("pay",it.pay).put("date",it.date)) }
            o.put("entries",es); a.put(o)
        }
        prefs.edit().putString("ledgers",a.toString()).apply()
    }
    private fun loadData() {
        ledgers.clear()
        try {
            val a=JSONArray(prefs.getString("ledgers","[]"))
            for(i in 0 until a.length()) {
                val o=a.getJSONObject(i); val l=Ledger(o.optString("name")); val es=o.optJSONArray("entries") ?: JSONArray()
                for(j in 0 until es.length()) { val e=es.getJSONObject(j); l.entries.add(Entry(e.optString("note"),e.optLong("receive"),e.optLong("pay"),e.optString("date"))) }
                ledgers.add(l)
            }
        } catch(_:Exception) {}
    }
    private fun toast(s:String) = Toast.makeText(this,s,Toast.LENGTH_LONG).show()
}
